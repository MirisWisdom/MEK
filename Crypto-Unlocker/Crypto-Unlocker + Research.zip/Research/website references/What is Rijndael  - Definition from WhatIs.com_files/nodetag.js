(function(){
var pfs={ "http://searchcloudstorage.techtarget.com/resources/Public-Cloud-Storage":{"nid":32659,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchfinancialsecurity.techtarget.com/resources":{"nid":32620,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchunifiedcommunications.techtarget.com/":{"nid":32621,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchfinancialapplications.techtarget.com/":{"nid":32663,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchcontentmanagement.techtarget.com/":{"nid":32557,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchmidmarketsecurity.techtarget.com/":{"nid":32665,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchnetworkingchannel.techtarget.com/":{"nid":32666,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchsolidstatestorage.techtarget.com/":{"nid":32670,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchcloudapplications.techtarget.com":{"nid":32657,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchmanufacturingerp.techtarget.com/":{"nid":32664,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchenterpriselinux.techtarget.com/":{"nid":32617,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchsecuritychannel.techtarget.com/":{"nid":32667,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchmobilecomputing.techtarget.com/":{"nid":30147,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchsoftwarequality.techtarget.com/":{"nid":32669,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchvirtualstorage.techtarget.com/":{"nid":32674,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchwindevelopment.techtarget.com/":{"nid":32675,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchstoragechannel.techtarget.com/":{"nid":32671,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchsystemschannel.techtarget.com/":{"nid":32672,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchcio-midmarket.techtarget.com/":{"nid":32619,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchenterprisewan.techtarget.com/":{"nid":32661,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchcloudsecurity.techtarget.com/":{"nid":32618,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchcloudprovider.techtarget.com/":{"nid":32658,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchexchange.techtarget.com/":{"nid":32662,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchtelecom.techtarget.com/":{"nid":32673,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://Searchvirtualdatacentre.co.uk":{"nid":31129,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchdomino.techtarget.com/":{"nid":32660,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://SearchBusinessAnalytics.com":{"nid":31133,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://SearchDataManagement.co.uk":{"nid":31131,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://searchsoa.techtarget.com/":{"nid":32668,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://SearchConsumerization.com":{"nid":31132,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://whatis.techtarget.com/":{"nid":32558,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://SearchSecurity.co.uk":{"nid":31134,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://SearchStorage.co.uk":{"nid":31130,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://Computerweekly.com":{"nid":31127,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"},
"http://MicroScope.co.uk":{"nid":31128,"tr":1,"ex":"http://searchdatacenter.techtarget.com/es/"} },d=document,w=window,u=(w.gm_fake_href)?w.gm_fake_href:w.location.href;

function z(n){
var s,u;

if (Math.random()>=n['tr']) {
	return;
}

var ar_nodes = ":32659:32620:32621:32663:32557:32665:32666:32670:32657:32664:32617:32667:30147:32669:32674:32675:32671:32672:32619:32661:32618:32658:32662:32673:31129:32660:31133:31131:32668:31132:32558:31134:31130:31127:31128:";
if (ar_nodes.indexOf(":"+n['nid']+":") >= 0) {	// adradar only
	(new Image).src="//amch.questionmarket.com/adscgen/adrad.php?survey_num=0&aicode=0&site="+n['nid'];
	return;
}



s=d.createElement('SCRIPT');
u='//content.dl-rms.com/dt/s/'+n['nid']+'/s.js';
s.src=u;
s.type='text/javascript';
d.getElementsByTagName('head')[0].appendChild(s);
}
function r() {
	var n="",p,x;
	while (1) {
		try {
			for (p in pfs) {
			  if (u.substring(0,p.length)==p && p.length > n.length) {
				if (pfs[p].ex) {
					x=new RegExp(pfs[p].ex,"i");
					if (x.test(u)) {
						continue;
					}
				}
				n=p;
			  }
			}
			if (n.length > 0) {
				z(pfs[n]);
				return;
			}
		} catch (e) {}
	
		if (w==top) {
			break;
		}
	
		if (w==window&&u!=d.referrer) {
			u=d.referrer;
		} else {
			w=w.parent;
		}
	}
}

if (d.readyState=="complete"){
	r();
} else if (w.addEventListener){ 
	w.addEventListener("load", r, false);
} else if (w.attachEvent){ 
	w.attachEvent("onload", r);
}
})();
